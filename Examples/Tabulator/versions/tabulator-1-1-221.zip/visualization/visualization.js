var vis;
/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 7943:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  initialize: function() { return /* binding */ initialize; }
});

// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(6540);
// EXTERNAL MODULE: ./node_modules/react-dom/client.js
var client = __webpack_require__(5338);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.symbol.js
var es_symbol = __webpack_require__(2675);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.symbol.description.js
var es_symbol_description = __webpack_require__(9463);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.symbol.iterator.js
var es_symbol_iterator = __webpack_require__(2259);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.symbol.to-primitive.js
var es_symbol_to_primitive = __webpack_require__(5700);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.error.cause.js
var es_error_cause = __webpack_require__(6280);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__(8706);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__(2008);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.from.js
var es_array_from = __webpack_require__(3418);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__(4423);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.iterator.js
var es_array_iterator = __webpack_require__(3792);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.reduce.js
var es_array_reduce = __webpack_require__(2712);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.slice.js
var es_array_slice = __webpack_require__(4782);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.date.to-primitive.js
var es_date_to_primitive = __webpack_require__(9572);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__(2010);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.number.constructor.js
var es_number_constructor = __webpack_require__(2892);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.define-properties.js
var es_object_define_properties = __webpack_require__(7945);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.define-property.js
var es_object_define_property = __webpack_require__(4185);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.get-own-property-descriptor.js
var es_object_get_own_property_descriptor = __webpack_require__(3851);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.get-own-property-descriptors.js
var es_object_get_own_property_descriptors = __webpack_require__(1278);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.keys.js
var es_object_keys = __webpack_require__(9432);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__(6099);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.parse-int.js
var es_parse_int = __webpack_require__(8940);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__(7495);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.test.js
var es_regexp_test = __webpack_require__(906);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__(8781);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__(1699);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__(7764);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__(5440);
// EXTERNAL MODULE: ./node_modules/core-js/modules/esnext.iterator.constructor.js
var esnext_iterator_constructor = __webpack_require__(8992);
// EXTERNAL MODULE: ./node_modules/core-js/modules/esnext.iterator.filter.js
var esnext_iterator_filter = __webpack_require__(4520);
// EXTERNAL MODULE: ./node_modules/core-js/modules/esnext.iterator.for-each.js
var esnext_iterator_for_each = __webpack_require__(3949);
// EXTERNAL MODULE: ./node_modules/core-js/modules/esnext.iterator.reduce.js
var esnext_iterator_reduce = __webpack_require__(8872);
// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom-collections.for-each.js
var web_dom_collections_for_each = __webpack_require__(3500);
// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__(2953);
// EXTERNAL MODULE: ./node_modules/tabulator-tables/dist/js/tabulator_esm.mjs
var tabulator_esm = __webpack_require__(4406);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.entries.js
var es_object_entries = __webpack_require__(5506);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.values.js
var es_object_values = __webpack_require__(6034);
;// ./src/themes/TabulatorThemes.js
function _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(r) { if (Array.isArray(r)) return r; }



















/**
 * Predefined theme settings for Tabulator.
 */
var themePresets = {
  midnight: {
    properties: {
      "--bg-color": "rgb(18, 18, 18)",
      "--border-color": "rgb(58, 58, 58)",
      "--header-bg": "rgb(37, 37, 37)",
      "--header-text": "rgb(230, 230, 230)",
      "--header-border": "rgb(58, 58, 58)",
      "--header-separator": "rgb(58, 58, 58)",
      "--header-hover-bg": "rgb(50, 50, 50)",
      "--header-hover-text": "rgb(240, 240, 240)",
      "--header-range-selected-bg": "rgb(55, 55, 55)",
      "--header-range-selected-text": "rgb(240, 240, 240)",
      "--header-sort-icon-active": "rgb(240, 240, 240)",
      "--header-sort-icon-inactive": "rgb(180, 180, 180)",
      "--header-filter-bg": "rgb(37, 37, 37)",
      "--header-filter-box": "rgb(55, 55, 55)",
      "--header-filter-text": "rgb(230, 230, 230)",
      "--header-filter-icon": "rgb(188, 188, 188)",
      "--row-bg-even": "rgb(25, 25, 25)",
      "--row-bg-odd": "rgb(25, 25, 25)",
      "--row-text-even": "rgb(230, 230, 230)",
      "--row-text-odd": "rgb(230, 230, 230)",
      "--row-border": "rgb(58, 58, 58)",
      "--row-hover-bg": "rgb(48, 48, 48)",
      "--row-hover-text": "rgb(255, 255, 255)",
      "--row-selected-bg": "rgb(89, 96, 112)",
      "--row-selected-text": "rgb(240, 240, 240)",
      "--row-calc-bg": "rgb(70, 70, 70)",
      "--row-group-bg": "rgb(46, 46, 46)",
      "--row-group-text": "rgb(212, 212, 212)",
      "--row-group-item-count-text": "rgb(0, 150, 80)",
      "--footer-bg": "rgb(20, 20, 20)",
      "--footer-text": "rgb(230, 230, 230)",
      "--edit-box": "rgb(29, 104, 205)"
    },
    initialColumnBorders: [".tabulator-row .tabulator-cell.tabulator-row-header {border-left: 10px solid #cccccc}"],
    rules: [".tabulator .tabulator-tableholder .tabulator-table .tabulator-row {margin-bottom: 2px; border: 1px solid #383838}", ".tabulator .tabulator-header .tabulator-col .tabulator-col-content {padding-right: 25px}", ".tabulator .tabulator-header {border-bottom: 3px solid var(--header-separator-color);}"]
  },
  basic: {
    properties: {
      "--bg-color": "rgb(255, 255, 255)",
      "--border-color": "rgb(200, 200, 200)",
      "--header-bg": "rgb(255, 255, 255)",
      "--header-text": "rgb(12, 12, 12)",
      "--header-border": "rgb(200, 200, 200)",
      "--header-separator": "rgb(200, 200, 200)",
      "--header-hover-bg": "rgb(225, 225, 225)",
      "--header-hover-text": "rgb(0, 0, 0)",
      "--header-range-selected-bg": "rgb(212, 212, 212)",
      "--header-range-selected-text": "rgb(0, 0, 0)",
      "--header-sort-icon-active": "rgb(0, 0, 0)",
      "--header-sort-icon-inactive": "rgb(66, 66, 66)",
      "--header-filter-bg": "rgb(255, 255, 255)",
      "--header-filter-box": "rgb(255, 255, 255)",
      "--header-filter-text": "rgb(0, 0, 0)",
      "--header-filter-icon": "rgb(25, 25, 25)",
      "--row-bg-even": "rgb(255, 255, 255)",
      "--row-bg-odd": "rgb(255, 255, 255)",
      "--row-text-even": "rgb(12, 12, 12)",
      "--row-text-odd": "rgb(12, 12, 12)",
      "--row-border": "rgb(200, 200, 200)",
      "--row-hover-bg": "rgb(215, 215, 215)",
      "--row-hover-text": "rgb(0, 0, 0)",
      "--row-selected-bg": "rgb(165, 225, 165)",
      "--row-selected-text": "rgb(0, 0, 0)",
      "--row-calc-bg": "rgb(235, 235, 235)",
      "--row-group-bg": "rgb(210, 210, 210)",
      "--row-group-text": "rgb(0, 0, 0)",
      "--row-group-item-count-text": "rgb(0, 150, 80)",
      "--footer-bg": "rgb(255, 255, 255)",
      "--footer-text": "rgb(0, 0, 0)",
      "--edit-box": "rgb(29, 104, 205)"
    },
    initialColumnBorders: [".tabulator-row .tabulator-cell.tabulator-row-header {border-left: 10px solid rgb(62, 174, 69)}"],
    rules: [".tabulator .tabulator-tableholder .tabulator-table .tabulator-row {margin-bottom: 2px; border: 1px solid #fff}", ".tabulator .tabulator-header .tabulator-col .tabulator-col-content {padding-right: 25px}", ".tabulator .tabulator-header {border-bottom: 3px solid var(--header-separator-color);}"]
  },
  default: {
    properties: {},
    initialColumnBorders: [".tabulator-row .tabulator-cell.tabulator-row-header {border-left: 10px solid #3759d7}"
    // Predefined themes cannot be overwritten, potential fix could be to:
    // [1] Use CSS variables and if one doesn't exist (commented out?) then use fall back default color
    // [2] Changes to style.css such as commenting variables by default and stating to the user to uncomment what they'd like to change/overwrite?
    // [3] If [2] then properties under the default theme option to be filled with the current default properties from all CSS variables in style.css
    // Will this be suitable? Is there a better approach?
    // Better approach to create a stylesheet and set priority but wouldn't this overwrite or be overwritten by style.css regardless?
    ],
    rules: [".tabulator .tabulator-tableholder .tabulator-table .tabulator-row {margin-bottom: 2px; border: 1px solid #fff}", ".tabulator .tabulator-header .tabulator-col .tabulator-col-content {padding-right: 25px}", ".tabulator .tabulator-header {border-bottom: 3px solid var(--header-separator-color);}"]
  }
};

/**
 * Table spacing presets.
 */
var tableSpacingValues = {
  small: "6px 4px",
  medium: "10px 6px",
  large: "14px 8px"
};

/**
 * Inserts a CSS rule into the first available stylesheet.
 * @param {CSSStyleSheet} stylesheet - The stylesheet to insert into.
 * @param {string} rule - The CSS rule to add.
 */
var insertRule = function insertRule(stylesheet, rule) {
  if (stylesheet !== null && stylesheet !== void 0 && stylesheet.insertRule) {
    stylesheet.insertRule(rule, stylesheet.cssRules.length);
  }
};

/**
 * Applies a set of CSS variables to the root element.
 * @param {Object} properties - Key-value pairs of CSS variables.
 */
var applyCSSVariables = function applyCSSVariables(properties) {
  var root = document.documentElement;
  Object.entries(properties).forEach(function (_ref) {
    var _ref2 = _slicedToArray(_ref, 2),
      key = _ref2[0],
      value = _ref2[1];
    root.style.setProperty(key, value);
  });
};

/**
 * Sets an individual CSS variable.
 * @param {string} variableName - The CSS variable name.
 * @param {string} value - The value to assign.
 */
var setCSSVariable = function setCSSVariable(variableName, value) {
  var root = document.documentElement;
  root.style.setProperty(variableName, value);
};

/**
 * Applies a visualization theme with optional table spacing.
 * @param {Object} options - Theme configuration options.
 * @param {string} options.theme - Name of the theme.
 * @param {string} options.tableSpacing - Spacing size.
 * @param {string} options.initialColumnBorders - Whether to apply column borders at the start of each row.
 */
var setVisualizationTheme = function setVisualizationTheme(_ref3) {
  var theme = _ref3.theme,
    tableSpacing = _ref3.tableSpacing,
    initialColumnBorders = _ref3.initialColumnBorders;
  var stylesheet = document.styleSheets[0];
  if (!stylesheet) return console.warn("No stylesheets found.");
  var selectedTheme = themePresets[theme === null || theme === void 0 ? void 0 : theme.toLowerCase()] || themePresets.default;
  applyCSSVariables(selectedTheme.properties);
  setCSSVariable("--table-spacing", tableSpacingValues[tableSpacing] || tableSpacingValues.small);
  selectedTheme.rules.forEach(function (rule) {
    return insertRule(stylesheet, rule);
  });
  if (initialColumnBorders && selectedTheme.initialColumnBorders) {
    Object.values(selectedTheme.initialColumnBorders).forEach(function (rule) {
      return insertRule(stylesheet, rule);
    });
  }
};

/**
 * Enables text wrapping for table cells and headers.
 */
var setTextWrapping = function setTextWrapping() {
  var stylesheet = document.styleSheets[0];
  if (!stylesheet) return console.warn("No stylesheets found.");
  var wrappingRules = [".tabulator-row .tabulator-cell {white-space: normal !important; word-break: break-word}", ".tabulator .tabulator-header .tabulator-col .tabulator-col-content .tabulator-col-title {white-space: normal !important; word-break: break-word}"];
  wrappingRules.forEach(function (rule) {
    return insertRule(stylesheet, rule);
  });
};
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.pad-start.js
var es_string_pad_start = __webpack_require__(8156);
;// ./src/formatters/TabulatorFormatters.js







var daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var daysOfWeekShort = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
var monthsOfYear = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var monthsOfYearShort = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
var isDateValid = function isDateValid(dateStr) {
  return !isNaN(Date.parse(dateStr));
};
var formatDate = function formatDate(cell, format) {
  var _cell$getValue;
  var cellValue = (cell === null || cell === void 0 || (_cell$getValue = cell.getValue) === null || _cell$getValue === void 0 ? void 0 : _cell$getValue.call(cell)) || cell;
  if (!isDateValid(cellValue)) {
    return "";
  }
  var dateObj = new Date(cellValue);
  var yearFull = dateObj.getFullYear().toString();
  var yearTwoDigit = yearFull.slice(-2);
  var monthIndex = dateObj.getMonth();
  var dayIndex = dateObj.getDay();
  var monthFullName = monthsOfYear[monthIndex];
  var monthShortName = monthsOfYearShort[monthIndex];
  var monthNumeric = (monthIndex + 1).toString().padStart("2", 0);
  var dayFullName = daysOfWeek[dayIndex];
  var dayShortName = daysOfWeekShort[dayIndex];
  var dayOfMonth = dateObj.getDate().toString().padStart("2", 0);
  var hoursPadded = dateObj.getHours().toString().padStart("2", 0); // Two-digit hour
  var hours = dateObj.getHours().toString(); // Single-digit hour
  var minutes = dateObj.getMinutes().toString().padStart("2", 0);
  var seconds = dateObj.getSeconds().toString().padStart("2", 0);
  var milliseconds = dateObj.getMilliseconds().toString();
  var terrestrialTime = hours >= 12 ? "PM" : "AM";
  return "".concat(format.replace("%ms", milliseconds).replace("%ss", seconds).replace("%mm", minutes).replace("%HH", hoursPadded).replace("%hh", hoursPadded).replace("%H", hours).replace("%h", hours).replace("%dddd", dayFullName).replace("%ddd", dayShortName).replace("%dd", dayOfMonth).replace("%MMMM", monthFullName).replace("%MMM", monthShortName).replace("%MM", monthNumeric).replace("%yyyy", yearFull).replace("%yy", yearTwoDigit).replace("%tt", terrestrialTime));
};
var getFormat = {
  datetime: function datetime(cell) {
    var _cell$getValue2;
    var cellValue = (cell === null || cell === void 0 || (_cell$getValue2 = cell.getValue) === null || _cell$getValue2 === void 0 ? void 0 : _cell$getValue2.call(cell)) || cell;
    if (isDateValid(cellValue)) {
      var dateObj = new Date(cellValue);
      return "".concat(dateObj.toDateString(), ", ").concat(dateObj.toLocaleTimeString());
    }
    return "";
  },
  date: function date(cell) {
    var _cell$getValue3;
    var cellValue = (cell === null || cell === void 0 || (_cell$getValue3 = cell.getValue) === null || _cell$getValue3 === void 0 ? void 0 : _cell$getValue3.call(cell)) || cell;
    if (isDateValid(cellValue)) {
      var dateObj = new Date(cellValue);
      return "".concat(dateObj.toLocaleDateString());
    }
    return "";
  },
  time: function time(cell) {
    var _cell$getValue4;
    var cellValue = (cell === null || cell === void 0 || (_cell$getValue4 = cell.getValue) === null || _cell$getValue4 === void 0 ? void 0 : _cell$getValue4.call(cell)) || cell;
    if (isDateValid(cellValue)) {
      var dateObj = new Date(cellValue);
      return "".concat(dateObj.toLocaleTimeString());
    }
    return "";
  }
};
;// ./src/formatters/TabulatorEditors.js


var dateFormats = ["datetime", "date", "time"];
var getEditorType = function getEditorType(format) {
  if (!format) {
    return;
  }
  if (format === 'star') {
    return true;
  }
  if (format.includes('%')) {
    return 'date';
  }
  if (dateFormats.includes(format)) {
    return 'date';
  }
  return 'input';
};
// EXTERNAL MODULE: ./node_modules/react-icons/bs/index.mjs
var bs = __webpack_require__(6973);
// EXTERNAL MODULE: ./node_modules/react-icons/fa6/index.mjs
var fa6 = __webpack_require__(9197);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.map.js
var es_map = __webpack_require__(6033);
;// ./src/visualization/libraries/columnTracker.js
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }















function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
var RESERVED_COLUMN_NAMES = ["noData", "groupBy", "uniqueId", "rowId"];

// Class to handle column naming conflicts
var ColumnTracker = /*#__PURE__*/function () {
  function ColumnTracker() {
    _classCallCheck(this, ColumnTracker);
    this.columns = new Map();
    this.groupTitles = new Map();
  }
  return _createClass(ColumnTracker, [{
    key: "getUniqueTitle",
    value: function getUniqueTitle(title) {
      var count = this.columns.get(title) || 0;
      this.columns.set(title, count + 1);
      if (RESERVED_COLUMN_NAMES.includes(title) || count > 0) {
        console.warn("Title '".concat(title, "' is reserved/duplicate. Renaming to '").concat(title, "_").concat(count, "'"));
        return "".concat(title, "_").concat(count);
      }
      return title;
    }
  }, {
    key: "getUniqueGroupTitle",
    value: function getUniqueGroupTitle(title) {
      var count = this.groupTitles.get(title) || 0;
      this.groupTitles.set(title, count + 1);
      if (count > 0) {
        console.warn("Title '".concat(title, "' is a duplicate group title. Renaming to '").concat(title, "_").concat(count, "'"));
        return "".concat(title, "_").concat(count);
      }
      return title;
    }
  }, {
    key: "clearMapping",
    value: function clearMapping() {
      this.columns.clear();
    }
  }]);
}();
;// ./src/visualization/libraries/contextMenuManager.js
function contextMenuManager_typeof(o) { "@babel/helpers - typeof"; return contextMenuManager_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, contextMenuManager_typeof(o); }















function contextMenuManager_defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, contextMenuManager_toPropertyKey(o.key), o); } }
function contextMenuManager_createClass(e, r, t) { return r && contextMenuManager_defineProperties(e.prototype, r), t && contextMenuManager_defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function contextMenuManager_classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperty(e, r, t) { return (r = contextMenuManager_toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function contextMenuManager_toPropertyKey(t) { var i = contextMenuManager_toPrimitive(t, "string"); return "symbol" == contextMenuManager_typeof(i) ? i : i + ""; }
function contextMenuManager_toPrimitive(t, r) { if ("object" != contextMenuManager_typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != contextMenuManager_typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
var ContextMenuManager = /*#__PURE__*/contextMenuManager_createClass(function ContextMenuManager(navigable, navigateFunc, _menuItems) {
  var _this = this;
  contextMenuManager_classCallCheck(this, ContextMenuManager);
  _defineProperty(this, "createMenu", function (event, cell) {
    var _cell$getColumn, _document$querySelect;
    event.preventDefault();
    _this.cleanup();
    if (!_this.menuItems.length || !_this.navigable && !((_cell$getColumn = cell.getColumn()) !== null && _cell$getColumn !== void 0 && (_cell$getColumn = _cell$getColumn.getDefinition()) !== null && _cell$getColumn !== void 0 && _cell$getColumn.editor)) return;
    _this.menu = document.createElement("div");
    _this.menu.classList.add("custom-context-menu");
    _this.menu.setAttribute("role", "menu");
    _this.menu.setAttribute("tabindex", "-1");
    _this.menuItems.forEach(function (item, index) {
      var menuItem = document.createElement("div");
      menuItem.className = "context-menu-item";
      menuItem.textContent = item.text;
      menuItem.setAttribute("data-action", item.action);
      menuItem.setAttribute("role", "menuitem");
      menuItem.setAttribute("tabindex", index === 0 ? "0" : "-1");
      var onClick = function onClick(e) {
        if (item.action === "navigate" && _this.navigateFunc) {
          _this.navigateFunc(e, cell);
        } else if (item.action === "edit") {
          cell.edit();
        }
        _this.cleanup();
      };
      menuItem.addEventListener("click", onClick);
      _this.menuItemHandlers.push(onClick);
      _this.menu.appendChild(menuItem);
    });
    var cellRect = cell.getElement().getBoundingClientRect();
    _this.menu.style.position = "absolute";
    _this.menu.style.left = "".concat(cellRect.left, "px");
    _this.menu.style.top = "".concat(cellRect.bottom, "px");
    document.body.appendChild(_this.menu);
    (_document$querySelect = document.querySelector('.context-menu-item[tabindex="0"]')) === null || _document$querySelect === void 0 || _document$querySelect.focus();
    document.body.addEventListener("click", _this.cleanupHelper);
    document.addEventListener("contextmenu", _this.contextListener);
    _this.menu.addEventListener("keydown", _this.handleKeydown);
  });
  _defineProperty(this, "cleanupHelper", function (e) {
    var button = e.which || e.button; // Firefox - Right click check
    if (button && button !== 1) {
      return;
    }
    _this.cleanup();
  });
  _defineProperty(this, "cleanup", function () {
    if (_this.menu) {
      _this.focusedItemIndex = 0;
      _this.menu.removeEventListener("keydown", _this.handleKeydown);
      document.body.removeEventListener("click", _this.cleanupHelper);
      document.removeEventListener("contextmenu", _this.contextListener);
      _this.menuItemHandlers.forEach(function (handler) {
        document.removeEventListener("click", handler);
      });
      _this.menuItemHandlers = [];
      _this.menu.remove();
      _this.menu = null;
    }
  });
  _defineProperty(this, "contextListener", function (e) {
    var element = e.srcElement || e.target;
    if (element.classList.contains("tabulator-cell") || element.classList.contains("context-menu-item")) {
      return;
    }
    _this.cleanup();
  });
  _defineProperty(this, "updateFocusedItem", function (menuItems, focusedItemIndex) {
    menuItems.forEach(function (item, index) {
      item.tabIndex = index === focusedItemIndex ? "0" : "-1";
    });
    menuItems[index].focus();
  });
  _defineProperty(this, "handleKeydown", function (event) {
    // Ignore IME composition
    if (!_this.menu || event.isComposing || event.keyCode === 229) {
      return;
    }
    var menuItems = _this.menu.querySelectorAll(".context-menu-item");
    switch (event.keyCode) {
      case 13:
        // Enter
        event.preventDefault();
        menuItems[_this.focusedItemIndex].click();
        break;
      case 27:
        // Escape
        event.preventDefault();
        _this.cleanup();
        break;
      case 38:
        // ArrowUp
        event.preventDefault();
        _this.focusedItemIndex = (_this.focusedItemIndex - 1 + menuItems.length) % menuItems.length;
        updateFocusedItem(menuItems, _this.focusedItemIndex);
        break;
      case 38:
        // ArrowDown
        event.preventDefault();
        _this.focusedItemIndex = (_this.focusedItemIndex + 1) % menuItems.length;
        updateFocusedItem(menuItems, _this.focusedItemIndex);
        break;
    }
  });
  this.menu = null;
  this.navigable = navigable;
  this.navigateFunc = navigateFunc;
  this.menuItems = _menuItems;
  this.menuItemHandlers = [];
  this.focusedItemIndex = 0;
});
;// ./src/visualization/libraries/tableManger.js
function tableManger_typeof(o) { "@babel/helpers - typeof"; return tableManger_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, tableManger_typeof(o); }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { tableManger_defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function tableManger_defineProperty(e, r, t) { return (r = tableManger_toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function tableManger_classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function tableManger_defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, tableManger_toPropertyKey(o.key), o); } }
function tableManger_createClass(e, r, t) { return r && tableManger_defineProperties(e.prototype, r), t && tableManger_defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function tableManger_toPropertyKey(t) { var i = tableManger_toPrimitive(t, "string"); return "symbol" == tableManger_typeof(i) ? i : i + ""; }
function tableManger_toPrimitive(t, r) { if ("object" != tableManger_typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != tableManger_typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function tableManger_slicedToArray(r, e) { return tableManger_arrayWithHoles(r) || tableManger_iterableToArrayLimit(r, e) || tableManger_unsupportedIterableToArray(r, e) || tableManger_nonIterableRest(); }
function tableManger_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function tableManger_iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function tableManger_arrayWithHoles(r) { if (Array.isArray(r)) return r; }
function _toConsumableArray(r) { return _arrayWithoutHoles(r) || _iterableToArray(r) || tableManger_unsupportedIterableToArray(r) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function tableManger_unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return tableManger_arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? tableManger_arrayLikeToArray(r, a) : void 0; } }
function _iterableToArray(r) { if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r); }
function _arrayWithoutHoles(r) { if (Array.isArray(r)) return tableManger_arrayLikeToArray(r); }
function tableManger_arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }












































var UI_CONFIG = {
  tableSettings: {
    maxWidth: 800 // Max width for demo table
  },
  columnSettings: {
    defaultWidth: 200 // Default column width
  }
};
var NO_COLUMN_DATA = [
// Placeholder when no column data is available
{
  title: "NO DATA",
  field: "noData",
  width: UI_CONFIG.columnSettings.defaultWidth,
  headerSort: false
}];

// Store collapsed column groups
var CollapsedGroups = {};

// Validate text alignment inputs
var validateAlignment = function validateAlignment(alignment) {
  return ["center", "right"].includes(alignment) ? alignment : "left";
};

// Formats data extracted from the table via the clipboard.
var formatAccessor = function formatAccessor(value, _data, _type, _params, column) {
  var _column$getDefinition;
  var formatter = (_column$getDefinition = column.getDefinition()) === null || _column$getDefinition === void 0 ? void 0 : _column$getDefinition.formatter;
  if (typeof formatter === "function") {
    try {
      return formatter(value);
    } catch (error) {
      console.warn("Formatter error:", error);
    }
  }
  return value;
};
var handleTableWidth = function handleTableWidth(tabulatorDivRef, customWidth, tableElement) {
  if (!tabulatorDivRef.current || !tableElement) return;
  var pxToNumber = function pxToNumber(pxString) {
    if (typeof pxString === "number") return pxString;
    return parseInt(pxString.replace("px", "")) || 0;
  };
  var totalColumnsWidth = tableElement.getColumns().reduce(function (sum, col) {
    return sum + (col.getWidth() || 100);
  }, 0);
  var finalWidth = customWidth && pxToNumber(customWidth) || Math.min(totalColumnsWidth, UI_CONFIG.tableSettings.maxWidth);
  tabulatorDivRef.current.style.width = "".concat(finalWidth - 2, "px"); // Reduced by 2px to avoid overflow cutting off borders
};
var getRowGroupHeader = function getRowGroupHeader(data) {
  return data.groupBy || "Other";
};
var removeBreakElements = function removeBreakElements(tabulatorElement) {
  // Remove <br> elements from the tables header contents to prevent gaps from appearing
  var headerContents = tabulatorElement.querySelector(".tabulator-header-contents");
  var breakTag = headerContents.querySelectorAll("br");
  breakTag.forEach(function (tag) {
    tag.remove();
  });
};
var createFilters = function createFilters(data, tabulatorElement, table) {
  removeBreakElements(tabulatorElement);
  if (!data.headerFiltering) return;
  var headers = tabulatorElement.querySelector(".tabulator-headers");
  if (!headers) return;
  var tabulatorFilters = document.createElement("div");
  tabulatorFilters.className = "tabulator-filters";
  tabulatorFilters.style.height = "38px";
  headers.insertAdjacentElement("afterend", tabulatorFilters);
  var columns = table.getColumns();
  columns.forEach(function (column) {
    var columnDef = column.getDefinition();
    var field = columnDef.field;
    var width = column.getWidth();
    var filterCell = document.createElement("div");
    filterCell.id = "filter-" + field;
    filterCell.className = "tabulator-col";
    filterCell.role = "columnheader";
    filterCell.style.minWidth = "40px";
    filterCell.style.width = width + "px";
    filterCell.style.borderTop = "1px solid #ddd";
    filterCell.style.height = "100%";
    var filterCellContent = document.createElement("div");
    filterCellContent.className = "tabulator-col-content";
    filterCell.appendChild(filterCellContent);
    var filterHolder = document.createElement("div");
    filterHolder.className = "tabulator-col-filter-holder";
    filterCellContent.appendChild(filterHolder);
    if (columnDef.filteringEnabled) {
      var filterCellFilter = document.createElement("div");
      filterCellFilter.className = "tabulator-col-filter";
      filterHolder.appendChild(filterCellFilter);
      if (field) {
        var input = document.createElement("input");
        input.type = "text";
        input.className = "tabulator-col-filter-input";
        input.addEventListener("keyup", function (e) {
          if (e.target.value == "") {
            table.clearFilter();
            return;
          }
          table.setFilter(field, "like", e.target.value);
        });
        filterCellFilter.appendChild(input);
      }
      var container = document.createElement("div");
      container.className = "tabulator-col-filter-icon";
      var root = (0,client.createRoot)(container);
      root.render(/*#__PURE__*/react.createElement(fa6/* FaFilter */.YsJ, null));
      filterHolder.appendChild(container);
    }
    tabulatorFilters.appendChild(filterCell);
    var columnToResize = null;
    var columnResizing = false;
    function trackColumnWidth() {
      if (columnResizing && columnToResize) {
        var liveWidth = columnToResize.getElement().offsetWidth;
        filterCell.style.width = liveWidth + "px";
      }
    }

    // Update column filters widths live when resizing a columns width
    table.on("columnResizing", function (resizedColumn) {
      if (resizedColumn.getField() !== field) return;
      columnResizing = true;
      columnToResize = resizedColumn;
      document.addEventListener("mousemove", trackColumnWidth);
    });

    // Update column filters width when column width is resized
    table.on("columnResized", function (resizedColumn) {
      if (resizedColumn.getField() !== field) return;
      columnResizing = false;
      columnToResize = null;
      document.removeEventListener("mousemove", trackColumnWidth);
      var newWidth = resizedColumn.getWidth();
      filterCell.style.width = newWidth + "px";
    });
  });
};
var _getDescendants = function getDescendants(group, ignoreFirstIndex) {
  // Get all columns within group
  var columns = [];
  var isFirstIndexIgnored = ignoreFirstIndex || false;
  if (group.columns) {
    group.columns.forEach(function (column) {
      if (!isFirstIndexIgnored) {
        isFirstIndexIgnored = true;
        return;
      }
      columns.push(column.uniqueId);
    });
  }
  if (group.subGroups) {
    group.subGroups.forEach(function (subGroup) {
      columns = [].concat(_toConsumableArray(columns), _toConsumableArray(_getDescendants(subGroup, isFirstIndexIgnored)));
    });
  }
  return columns;
};
var HeaderContent = function HeaderContent(_ref) {
  var initialValue = _ref.initialValue,
    group = _ref.group,
    table = _ref.table;
  var _useState = (0,react.useState)({}),
    _useState2 = tableManger_slicedToArray(_useState, 2),
    _isCollapsed = _useState2[0],
    setIsCollapsed = _useState2[1];
  var groupId = group.uniqueId;
  var _adjustColumns = function adjustColumns(targetGroup, isCollapsed) {
    var parentCollapsed = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
    var groupColumns = _getDescendants(targetGroup);
    if (parentCollapsed) {
      // Keep child columns hidden
      groupColumns.forEach(function (field) {
        table.hideColumn(field);

        // Hide columns filter if exists
        var filterContainer = document.getElementById("filter-" + field);
        var filterHolder = filterContainer.getElementsByClassName("tabulator-col-filter-holder");
        var filter = filterHolder[0];
        if (filter) {
          filter.hidden = true;
        }
      });
      return;
    }
    groupColumns.forEach(function (field) {
      var filterContainer = document.getElementById("filter-" + field);
      var filterHolder = filterContainer.getElementsByClassName("tabulator-col-filter-holder");
      var filter = filterHolder[0];
      if (isCollapsed) {
        table.hideColumn(field);
        if (filter) {
          filter.hidden = true;
        }
      } else {
        // Only show if parent group is not collapsed
        table.showColumn(field);
        if (filter) {
          filter.hidden = false;
        }
      }
    });
    if (targetGroup.subGroups) {
      targetGroup.subGroups.forEach(function (subGroup) {
        if (subGroup.columns) {
          var subGroupId = subGroup.uniqueId;
          _adjustColumns(subGroup, CollapsedGroups[subGroupId] || false, isCollapsed || parentCollapsed);
        }
      });
    }
  };
  var toggleGroup = function toggleGroup() {
    var newCollapsedState = !CollapsedGroups[groupId];
    setIsCollapsed(newCollapsedState);
    CollapsedGroups[groupId] = newCollapsedState;
    _adjustColumns(group, newCollapsedState);
    table.redraw();
  };
  return /*#__PURE__*/react.createElement("span", {
    className: "flex items-center gap-2"
  }, initialValue, /*#__PURE__*/react.createElement("div", {
    className: "dropdown"
  }, /*#__PURE__*/react.createElement("div", {
    className: "menu-icon",
    onClick: toggleGroup
  }, CollapsedGroups[groupId] ? /*#__PURE__*/react.createElement(bs/* BsCaretRightFill */.O0X, null) : /*#__PURE__*/react.createElement(bs/* BsCaretDownFill */.UBI, null))));
};
var TableManager = /*#__PURE__*/function () {
  function TableManager(config, containerRef) {
    tableManger_classCallCheck(this, TableManager);
    this.config = config;
    this.containerRef = containerRef;
    this.contextMenu = null;
    this.navigable = false;
    this.navigateFunc = null;
    this.menuItems = [];
    this.tableConfig = {};
    this.table = null;
  }
  return tableManger_createClass(TableManager, [{
    key: "transformJson",
    value: function transformJson(data) {
      // Transforms JSON data into a format suitable for Tabulator
      var columnTracker = new ColumnTracker();
      var tabulatorData = [];
      data.rows.forEach(function (row) {
        var flatRow = {
          rowId: row.id,
          groupBy: row.groupBy
        };
        if (row.columns) {
          row.columns.forEach(function (column) {
            var columnKey = columnTracker.getUniqueTitle(column.title);
            flatRow[columnKey] = column.content;
          });
        }
        if (row.groups) {
          row.groups.forEach(function (group) {
            if (group.columns) {
              group.columns.forEach(function (column) {
                var columnKey = columnTracker.getUniqueTitle(column.title);
                flatRow[columnKey] = column.content;
              });
            }
            if (group.subGroups) {
              group.subGroups.forEach(function (subGroup) {
                if (subGroup.columns) {
                  subGroup.columns.forEach(function (column) {
                    var columnKey = columnTracker.getUniqueTitle(column.title);
                    flatRow[columnKey] = column.content;
                  });
                }
              });
            }
          });
        }
        columnTracker.clearMapping();
        tabulatorData.push(flatRow);
      });
      return tabulatorData;
    }
  }, {
    key: "initializeTable",
    value: function initializeTable() {
      var _this$config$style$st,
        _this$config$style$st2,
        _this$config$style$st3,
        _this$config$style$st4,
        _this = this,
        _this$config$style$st5,
        _this$config$data$row,
        _this$config$style$st6;
      if (!this.containerRef.current) return;
      console.log("debug"); // Kept to avoid trouble locating this file in Inspect Element Sources

      setVisualizationTheme({
        theme: (_this$config$style$st = this.config.style.stylingOptions) === null || _this$config$style$st === void 0 ? void 0 : _this$config$style$st.theme,
        tableSpacing: (_this$config$style$st2 = this.config.style.stylingOptions) === null || _this$config$style$st2 === void 0 ? void 0 : _this$config$style$st2.tableSpacing,
        initialColumnBorders: ((_this$config$style$st3 = this.config.style.stylingOptions) === null || _this$config$style$st3 === void 0 ? void 0 : _this$config$style$st3.initialColumnBorders) === true
      });
      if (((_this$config$style$st4 = this.config.style.stylingOptions) === null || _this$config$style$st4 === void 0 ? void 0 : _this$config$style$st4.wrapText) === true) {
        setTextWrapping();
      }
      if (this.config.data.navigable) {
        this.navigable = true;
        this.menuItems.push({
          text: "Navigate to Element",
          action: "navigate"
        });
        this.navigateFunc = function (event, cell) {
          var _row$getData;
          var row = cell.getRow();
          var rowId = row === null || row === void 0 || (_row$getData = row.getData()) === null || _row$getData === void 0 ? void 0 : _row$getData.rowId;
          if (rowId) {
            _this.config.functions.performAction("Cell Click", rowId, event);
          }
        };
      }
      if (this.config.data.editable) {
        this.menuItems.push({
          text: "Edit Cell",
          action: "edit"
        });
      }
      this.contextMenu = new ContextMenuManager(this.navigable, this.navigateFunc, this.menuItems);
      this.tableConfig = _objectSpread({
        data: this.transformJson(this.config.data),
        layout: "fitDataTable",
        responsiveLayout: false,
        resizableRows: this.config.data.resizable,
        editTriggerEvent: "dblclick",
        // Column sorting
        headerSortClickElement: "icon",
        headerSortElement: function headerSortElement(_column, dir) {
          var container = document.createElement("div");
          var root = (0,client.createRoot)(container);
          switch (dir) {
            case "asc":
              root.render(/*#__PURE__*/react.createElement("div", {
                className: "sorting-icon",
                "aria-sort": "ascending"
              }, /*#__PURE__*/react.createElement("span", null, /*#__PURE__*/react.createElement(bs/* BsSortUp */.NXG, null))));
              break;
            case "desc":
              root.render(/*#__PURE__*/react.createElement("div", {
                className: "sorting-icon",
                "aria-sort": "descending"
              }, /*#__PURE__*/react.createElement("span", null, /*#__PURE__*/react.createElement(bs/* BsSortDown */.sIf, null))));
              break;
            default:
              root.render(/*#__PURE__*/react.createElement("div", {
                className: "sorting-icon",
                "aria-sort": "none"
              }, /*#__PURE__*/react.createElement("span", null, /*#__PURE__*/react.createElement(bs/* BsSortUp */.NXG, null))));
          }
          return container;
        },
        // Enable range selection
        selectableRange: 1,
        // Allow only one range at a time
        selectableRangeColumns: true,
        selectableRangeRows: (_this$config$style$st5 = this.config.style.stylingOptions) === null || _this$config$style$st5 === void 0 || (_this$config$style$st5 = _this$config$style$st5.initialRow) === null || _this$config$style$st5 === void 0 ? void 0 : _this$config$style$st5.enabled,
        selectableRangeClearCells: true,
        // Allow users to clear the contents of a selected range by pressing backspace or delete

        // Clipboard configuration
        clipboard: true,
        // Enable clipboard functionality
        clipboardCopyRowRange: "range",
        // Include selected range in the clipboard output
        clipboardPasteParser: "range",
        // Accept smaller ranges of cells
        clipboardPasteAction: "range",
        // Update rows in active range with parsed range data
        clipboardCopyConfig: {
          columnHeaders: false,
          // Exclude column headers in clipboard output
          columnGroups: false,
          // Exclude column groups in column headers for printed table
          rowHeaders: false,
          // Exclude row headers in clipboard output
          rowGroups: false // Exclude row groups in clipboard output
        },
        columns: this.createColumnDefinition()
      }, (_this$config$data$row = this.config.data.rows[0]) !== null && _this$config$data$row !== void 0 && _this$config$data$row.groupRows ? {
        groupBy: getRowGroupHeader,
        groupHeader: function groupHeader(value, count) {
          return value + "<span>(" + count + " items)</span>";
        }
      } : {});
      if ((_this$config$style$st6 = this.config.style.stylingOptions) !== null && _this$config$style$st6 !== void 0 && (_this$config$style$st6 = _this$config$style$st6.initialRow) !== null && _this$config$style$st6 !== void 0 && _this$config$style$st6.enabled) {
        var _this$config$style$st7;
        this.tableConfig.rowHeader = {
          title: (_this$config$style$st7 = this.config.style.stylingOptions.initialRow.title) !== null && _this$config$style$st7 !== void 0 ? _this$config$style$st7 : "ID",
          resizable: false,
          frozen: this.config.style.stylingOptions.initialRow.frozen === true,
          width: 40,
          hozAlign: "center",
          formatter: "rownum",
          cssClass: "range-header-col",
          editor: false,
          headerSort: false
        };
      }
      this.table = new tabulator_esm/* TabulatorFull */.mu(this.containerRef.current, this.tableConfig);
      var newHeight = parseInt(this.config.height - 2); // Reducing by 2 pixels to avoid overflow cutting off outer borders when using Tabulator in mood
      this.containerRef.current.style.height = "".concat(newHeight, "px");
      handleTableWidth(this.containerRef, this.config.width, this.table);
      var self = this; // For Tabulator callbacks to capture the correct 'this' value

      // Create custom header filters
      this.table.on("tableBuilt", function () {
        createFilters(self.config.data, self.containerRef.current, self.table);
      });

      // Re-adjust tables sizing after data has loaded to avoid visual bugs
      this.table.on("dataProcessed", function () {
        setTimeout(function () {
          self.table.redraw();
        }, 100);
      });
    }
  }, {
    key: "createColumnDefinition",
    value: function createColumnDefinition() {
      var _this$config$data$row2,
        _firstRow$columns,
        _this2 = this,
        _firstRow$groups;
      var columnTracker = new ColumnTracker();
      var columns = [];
      var firstRow = (_this$config$data$row2 = this.config.data.rows) === null || _this$config$data$row2 === void 0 ? void 0 : _this$config$data$row2[0];
      firstRow === null || firstRow === void 0 || (_firstRow$columns = firstRow.columns) === null || _firstRow$columns === void 0 || _firstRow$columns.forEach(function (col) {
        var uniqueField = columnTracker.getUniqueTitle(col.title);
        col.uniqueId = uniqueField;
        columns.push({
          title: col.title,
          field: uniqueField,
          width: col.width || UI_CONFIG.columnSettings.defaultWidth,
          headerHozAlign: validateAlignment(col.alignment),
          hozAlign: validateAlignment(col.alignment),
          frozen: col.frozen || false,
          headerSort: _this2.config.data.columnSorting && col.columnSorter || false,
          resizable: _this2.config.data.resizable && col.resizable || false,
          editor: _this2.config.data.editable && col.editable ? getEditorType(col.format) || true : false,
          formatter: getFormat[col.format] || (col.format && col.format.includes("%") ? function (cell) {
            return formatDate(cell, col.format);
          } : col.format),
          contextMenu: _this2.contextMenu.createMenu,
          accessorClipboard: formatAccessor,
          filteringEnabled: col.headerFilter,
          topCalc: _this2.config.data.topRowCalculations ? col.topCalc : null
        });
      });
      firstRow === null || firstRow === void 0 || (_firstRow$groups = firstRow.groups) === null || _firstRow$groups === void 0 || _firstRow$groups.forEach(function (group) {
        var _group$columns, _group$subGroups;
        var groupColumns = [];
        var uniqueTitle = columnTracker.getUniqueGroupTitle(group.title);
        group.uniqueId = uniqueTitle;
        (_group$columns = group.columns) === null || _group$columns === void 0 || _group$columns.forEach(function (col) {
          var _this2$config$style$s;
          var uniqueField = columnTracker.getUniqueTitle(col.title);
          var displayTitle = ((_this2$config$style$s = _this2.config.style.stylingOptions) === null || _this2$config$style$s === void 0 ? void 0 : _this2$config$style$s.showDetailedTitles) && "".concat(uniqueTitle, ": ").concat(col.title);
          col.uniqueId = uniqueField;
          groupColumns.push({
            title: displayTitle || col.title,
            field: uniqueField,
            width: col.width || UI_CONFIG.columnSettings.defaultWidth,
            headerHozAlign: validateAlignment(col.alignment),
            hozAlign: validateAlignment(col.alignment),
            frozen: col.frozen || false,
            headerSort: _this2.config.data.columnSorting && col.columnSorter || false,
            resizable: _this2.config.data.resizable && col.resizable || false,
            editor: _this2.config.data.editable && col.editable ? getEditorType(col.format) || true : false,
            formatter: getFormat[col.format] || (col.format && col.format.includes("%") ? function (cell) {
              return formatDate(cell, col.format);
            } : col.format),
            contextMenu: _this2.contextMenu.createMenu,
            accessorClipboard: formatAccessor,
            filteringEnabled: col.headerFilter,
            topCalc: _this2.config.data.topRowCalculations ? col.topCalc : null
          });
        });
        group === null || group === void 0 || (_group$subGroups = group.subGroups) === null || _group$subGroups === void 0 || _group$subGroups.forEach(function (subGroup) {
          var _subGroup$columns;
          var subGroupColumns = [];
          var uniqueTitle = columnTracker.getUniqueGroupTitle(subGroup.title);
          subGroup.uniqueId = uniqueTitle;
          (_subGroup$columns = subGroup.columns) === null || _subGroup$columns === void 0 || _subGroup$columns.forEach(function (col) {
            var _this2$config$style$s2;
            var uniqueField = columnTracker.getUniqueTitle(col.title);
            var displayTitle = ((_this2$config$style$s2 = _this2.config.style.stylingOptions) === null || _this2$config$style$s2 === void 0 ? void 0 : _this2$config$style$s2.showDetailedTitles) && "".concat(uniqueTitle.title, ": ").concat(col.title);
            col.uniqueId = uniqueField;
            subGroupColumns.push({
              title: displayTitle || col.title,
              field: uniqueField,
              width: col.width || UI_CONFIG.columnSettings.defaultWidth,
              headerHozAlign: validateAlignment(col.alignment),
              hozAlign: validateAlignment(col.alignment),
              frozen: col.frozen || false,
              headerSort: _this2.config.data.columnSorting && col.columnSorter || false,
              resizable: _this2.config.data.resizable && col.resizable || false,
              editor: _this2.config.data.editable && col.editable ? getEditorType(col.format) || true : false,
              formatter: getFormat[col.format] || (col.format && col.format.includes("%") ? function (cell) {
                return formatDate(cell, col.format);
              } : col.format),
              contextMenu: _this2.contextMenu.createMenu,
              accessorClipboard: formatAccessor,
              filteringEnabled: col.headerFilter,
              topCalc: _this2.config.data.topRowCalculations ? col.topCalc : null
            });
          });
          groupColumns.push({
            title: uniqueTitle,
            columns: (subGroupColumns === null || subGroupColumns === void 0 ? void 0 : subGroupColumns.length) <= 0 && NO_COLUMN_DATA || subGroupColumns,
            titleFormatter: function titleFormatter(cell) {
              if ((subGroupColumns === null || subGroupColumns === void 0 ? void 0 : subGroupColumns.length) <= 1) {
                return uniqueTitle;
              }
              var container = document.createElement("div");
              var root = (0,client.createRoot)(container);
              root.render(/*#__PURE__*/react.createElement(HeaderContent, {
                initialValue: cell.getValue(),
                group: subGroup,
                table: this.table
              }));
              return container;
            }
          });
        });
        columns.push({
          title: uniqueTitle,
          columns: groupColumns.length <= 0 && NO_COLUMN_DATA || groupColumns,
          titleFormatter: function titleFormatter(cell) {
            if ((groupColumns === null || groupColumns === void 0 ? void 0 : groupColumns.length) <= 1) {
              return uniqueTitle;
            }
            var container = document.createElement("div");
            var root = (0,client.createRoot)(container);
            root.render(/*#__PURE__*/react.createElement(HeaderContent, {
              initialValue: cell.getValue(),
              group: group,
              table: this.table
            }));
            return container;
          }
        });
      });
      return columns;
    }
  }]);
}();
;// ./src/visualization/app.js


var TabulatorApp = function TabulatorApp(_ref) {
  var config = _ref.config;
  var containerRef = (0,react.useRef)(null);
  var tableRef = (0,react.useRef)(null);
  (0,react.useEffect)(function () {
    if (containerRef.current && tableRef.current) {
      return;
    }
    ;
    var manager = new TableManager(config, containerRef);
    manager.initializeTable();
    tableRef.current = manager;
  }, [config]);
  return /*#__PURE__*/react.createElement("div", {
    ref: containerRef
  });
};
/* harmony default export */ var app = (TabulatorApp);
;// ./src/visualization/visualization.js



function initialize(config) {
  var mainElement = document.getElementById(config.element);
  var root = (0,client.createRoot)(mainElement);
  root.render(/*#__PURE__*/react.createElement(react.StrictMode, null, /*#__PURE__*/react.createElement(app, {
    config: config
  })));
}

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	!function() {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = function(result, chunkIds, fn, priority) {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var chunkIds = deferred[i][0];
/******/ 				var fn = deferred[i][1];
/******/ 				var priority = deferred[i][2];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every(function(key) { return __webpack_require__.O[key](chunkIds[j]); })) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	!function() {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	!function() {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			781: 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = function(chunkId) { return installedChunks[chunkId] === 0; };
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = function(parentChunkLoadingFunction, data) {
/******/ 			var chunkIds = data[0];
/******/ 			var moreModules = data[1];
/******/ 			var runtime = data[2];
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some(function(id) { return installedChunks[id] !== 0; })) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkvis"] = self["webpackChunkvis"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	}();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, [644,39,695], function() { return __webpack_require__(7943); })
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	vis = __webpack_exports__;
/******/ 	
/******/ })()
;